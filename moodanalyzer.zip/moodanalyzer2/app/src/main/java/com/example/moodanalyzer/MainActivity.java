package com.example.moodanalyzer;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText edtMoodInput;
    private Button btnAnalyzeMood;
    private TextView tvMoodResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind views
        edtMoodInput = findViewById(R.id.edtMoodInput);
        btnAnalyzeMood = findViewById(R.id.btnAnalyzeMood);
        tvMoodResult = findViewById(R.id.tvMoodResult);

        // Set onClickListener for the button
        btnAnalyzeMood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the entered mood text
                String moodText = edtMoodInput.getText().toString().toLowerCase();

                // Analyze the mood based on the entered text
                String moodResult = analyzeMood(moodText);

                // Display the result in the TextView
                tvMoodResult.setText(moodResult);
            }
        });
    }

    // Simple mood analysis logic based on keyword matching
    private String analyzeMood(String text) {
        if (text.contains("happy") || text.contains("joy") || text.contains("excited")) {
            return "You are feeling Happy! 😊 Keep up the positive energy!";
        } else if (text.contains("sad") || text.contains("down") || text.contains("unhappy")) {
            return "You seem sad. 😞 It's okay to feel down sometimes.";
        } else if (text.contains("angry") || text.contains("furious") || text.contains("rage")) {
            return "You seem angry. 😡 Take a deep breath and try to calm down.";
        } else if (text.contains("nervous") || text.contains("anxious") || text.contains("worried")) {
            return "You are feeling Nervous. 😟 Take a moment to breathe and relax.";
        } else {
            return "Mood is Neutral. 😐 It's okay to feel neutral sometimes.";
        }
    }
}